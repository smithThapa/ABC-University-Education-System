// Toggle the side navigation
$('#sidebarToggle').on('click', function(e) {
  e.preventDefault();
  $('body').toggleClass('sidebar-toggled');
  $('.sidebar').toggleClass('toggled');
});
